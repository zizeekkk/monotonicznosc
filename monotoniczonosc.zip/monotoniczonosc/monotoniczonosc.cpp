﻿#include <iostream>
using namespace std;

int main() 
{
	cout << "Wypisz ciag liczb\n"; 
	int ciag = 0;
	cin >> ciag; 
	int liczba = 0;
	int lp = 0;
	
	bool malejacy = true, rosnacy = true;
	for (int i = 0; i < ciag ; i++) {
		cin >> liczba;
		lp = ciag;
		cout<< "liczba:" << liczba << endl; // sprawdzenie jaka liczba jest intem liczby
		cout<< "lp:" << lp << endl; // sprawdzenie jaka liczba jest intem liczby poprzedniej
		if (liczba > ciag)
		{
			ciag = malejacy = false;	
		}
		if (liczba < ciag)
		{
			ciag = rosnacy = false;
		}
	}
	if (ciag = rosnacy)
	{
		cout << "ciag rosnacy";
	}
	else if (ciag = malejacy)
	{
		cout << "ciag malejacy";
	}
}